module.exports = {
  setupFilesAfterEnv: ["./test/jest-setup.js"],
  testEnvironment: "jsdom"
};
